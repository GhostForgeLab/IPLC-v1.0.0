# IPLC Light

面向 Debian 13 + nftables 的轻量端口转发管理脚本。

## 设计原则

- 不做 Web 面板。
- 不接管或删除现有外部 DNAT 规则。
- 新增规则统一放入独立 `ip iplc_light` 表。
- 每次添加/删除/恢复前自动备份。
- 添加时同时生成 TCP + UDP DNAT 与对应 masquerade。
- 每次变更先执行 nftables 事务语法检查，检查通过后才应用。
- 持久化文件：`/etc/nftables.d/iplc-light.nft`
- 状态文件：`/var/lib/iplc-light/rules.json`
- 备份目录：`/var/backups/iplc-light`

## 安装

```bash
tar -xzf iplc-light.tar.gz
cd iplc-light
sudo bash install.sh
```

## 命令

```bash
iplc-list
iplc-add
iplc-del
iplc-backup
iplc-restore
iplc-check
```

也可非交互添加：

```bash
iplc-add 37185 1.2.3.4 25884 -y
```

删除：

```bash
iplc-del 37185 -y
```

## 对现有 37183 / 37184 的处理

安装不会迁移、删除或重写现有生产规则。
`iplc-list` 会把这些规则显示成“原有/外部”。
`iplc-del` 默认拒绝删除外部规则，避免误伤当前转发。

后续新加的规则由 IPLC Light 全程管理。
